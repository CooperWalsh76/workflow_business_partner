$.context.BPRequest.SearchTerm1 = $.context.DefaultRuleOutput.SearchTerm;
